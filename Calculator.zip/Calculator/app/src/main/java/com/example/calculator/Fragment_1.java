package com.example.calculator;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;


public class Fragment_1 extends Fragment {


    public Fragment_1() {
        // Required empty public constructor
    }


    String name;
    EditText edit;
    Button bttn;
    Boolean add1,multi,div1,sub1,mod1;
    Double res1;
    int count=0;
    int  check=0;

    ///////////////////for storing th first String into double form////////////////////////////

    void storePre() {
        if (!TextUtils.isEmpty(edit.getText())) {
            res1 = Double.parseDouble(edit.getText() + "");
        }
    }
    void setFalse() {

        mod1 = sub1 = div1 = add1 = multi = false;
    }

    void clear()
    {
        res1=null;
        count=0;
        check=0;
        edit.setText(null);
    }

    void check(){
        name=edit.getText().toString();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_1, container, false);
       ///////// Buttons//////////////////////////////////////////////////////

        Button button1 = view.findViewById(R.id.button1);

        Button button2 = view.findViewById(R.id.button2);
        Button button3 = view.findViewById(R.id.button3);
        Button button4 =view.findViewById(R.id.button4);
        Button button5 = view.findViewById(R.id.button5);
        Button button6 = view.findViewById(R.id.button6);
        Button button7 =view. findViewById(R.id.button7);
        Button button8 = view.findViewById(R.id.button8);
        Button button9 = view.findViewById(R.id.button9);

        ///////////////////////////Buttons of Operation ////////////////////////////////////////////

        Button buttonc = view.findViewById(R.id.buttonc);
        Button mod = view.findViewById(R.id.mod);
        Button buttond = view.findViewById(R.id.buttond);
        Button div = view.findViewById(R.id.div);
        Button mult = view.findViewById(R.id.mult);
        Button sub = view.findViewById(R.id.sub);
        Button add = view.findViewById(R.id.add);
        Button eql = view.findViewById(R.id.eql);
        Button point = view.findViewById(R.id.point);
        Button zero = view.findViewById(R.id.zero);
        Button tzero = view.findViewById(R.id.tzero);
        edit = view.findViewById(R.id.edit);






        ////////////////////////////////////// Handling button clicks/////////////////////////////

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                edit.setText(edit.getText() + "1");
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                edit.setText(edit.getText() + "2");
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                edit.setText(edit.getText() + "3");
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                edit.setText(edit.getText() + "4");
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                edit.setText(edit.getText() + "5");
            }
        });

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                edit.setText(edit.getText() + "6");
            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                edit.setText(edit.getText() + "7");
            }
        });

        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                edit.setText(edit.getText() + "8");
            }
        });

        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                edit.setText(edit.getText() + "9");
            }
        });

        mod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                storePre();
                setFalse();
                mod1 = true;
                edit.setText(null);
            }
        });

        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                storePre();
                count=0;
                setFalse();
                div1 = true;
                edit.setText(null);
            }
        });

        mult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                storePre();
                count=0;
                setFalse();
                multi = true;
                edit.setText(null);
            }

        });

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //edit.setText(edit.getText() + "-");

                storePre();
                count=0;
                setFalse();
                sub1 = true;
                edit.setText(null);
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                storePre();
                count=0;
                setFalse();
                add1 = true;
                edit.setText(null);

            }
        });

        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                if(edit.getText().toString().equals("0"))
                {
                    edit.setText(edit.getText() + "");
                }
                else {
                    edit.setText(edit.getText() + "0");
                }
            }
        });

        tzero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                if(edit.getText().toString().equals("0"))
                {
                    edit.setText(edit.getText() + "");
                }
                else{
                    edit.setText(edit.getText() + "0");
                }
            }
        });

        buttond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                check();
                if (name.equals(""))
                {

                }
                else {

                    edit.setText(name.substring(0, name.length() - 1));
                }
            }
        });

        point.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {

                if(edit.getText().toString().equals(""))
                {
                    edit.setText(edit.getText() + "0.");
                    check=1;
                }
                else if (count==1)
                {
                    edit.setText(edit.getText() + "");
                }
                else if(check==0) {
                    edit.setText(edit.getText() + ".");
                    count = 1;
                }
            }
        });

/////////////////////Handling the equal/result Click////////////////////////////////

        eql.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                if(res1==null)
                    edit.setText(edit.getText()+"");

                else   if (add1)
                {
                    edit.setText(res1 + Double.parseDouble(edit.getText() + "") + "");

                }
                else   if (sub1)
                {
                    edit.setText(res1 - Double.parseDouble(edit.getText() + "") + "");
                }
                else  if (multi)
                {
                    edit.setText(res1 * Double.parseDouble(edit.getText() + "") + "");
                }
                else   if (div1)
                {
                    edit.setText(res1 / Double.parseDouble(edit.getText() + "") + "");
                }
                else    if (mod1)
                {
                    edit.setText(res1 % Double.parseDouble(edit.getText() + "") + "");
                }
            }
        });

/////////////////////////////////clearing the edit text///////////////////////////////////

        buttonc.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                clear();
            }
        });






        return view;
    }
}