package com.example.calculator;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;


public class Fragment_2 extends Fragment {



    public Fragment_2() {
        // Required empty public constructor
    }


    String name;
    EditText edit1,  edit2 ;
    Button eql;
    Double res1;
    int count=0;
    int check1=0;
    void check()
    {
        name=edit1.getText().toString();
    }
    void storePre()
    {

        if (!TextUtils.isEmpty(edit1.getText()))
        {
            res1 = Double.parseDouble(edit1.getText() + "");
        }
    }

//////////////////////////////////////for clearing the data///////////////////////////////////

    void clear ()

    {
        edit1.setText(null);
        edit2.setText(null);
        check1=0;
        count=0;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_2, container, false);



        Button button1 = view.findViewById(R.id.button1);

        Button button2 = view. findViewById(R.id.button2);
        Button button3 =  view.findViewById(R.id.button3);
        Button button4 = view. findViewById(R.id.button4);
        Button button5 =  view.findViewById(R.id.button5);
        Button button6 =  view.findViewById(R.id.button6);
        Button button7 =  view.findViewById(R.id.button7);
        Button button8 =  view.findViewById(R.id.button8);
        Button button9 = view. findViewById(R.id.button9);
        Button buttonc =  view.findViewById(R.id.buttonc);
        Button tZero =  view.findViewById(R.id.tzero);
        Button zero =  view.findViewById(R.id.zero);
        Button point =  view.findViewById(R.id.point);
        Button del= view.findViewById(R.id.del);
        eql =  view.findViewById(R.id.eql);
        edit1 =  view.findViewById(R.id.edit1);
        edit2 =  view.findViewById(R.id.edit2);

///////////////////////////////////handling the click listner///////////////////////////////////////////

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edit1.setText(edit1.getText() + "1");
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edit1.setText(edit1.getText() + "2");
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edit1.setText(edit1.getText() + "3");
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edit1.setText(edit1.getText() + "4");
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edit1.setText(edit1.getText() + "5");
            }
        });

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edit1.setText(edit1.getText() + "6");
            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edit1.setText(edit1.getText() + "7");
            }
        });

        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edit1.setText(edit1.getText() + "8");
            }
        });

        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edit1.setText(edit1.getText() + "9");
            }
        });

        point.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(edit1.getText().toString().equals(""))
                {
                    edit1.setText(edit1.getText() + "0.");
                    check1=1;
                }
                else if (count==1)
                {
                    edit1.setText(edit1.getText() + "");
                }
                else if(check1==0) {
                    edit1.setText(edit1.getText() + ".");
                    count = 1;
                }
            }
        });

        tZero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edit1.getText().toString().equals("0")) {
                    edit1.setText(edit1.getText() + "");
                } else {
                    edit1.setText(edit1.getText() + "0");
                }
            }
        });

        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edit1.getText().toString().equals("0"))
                {
                    edit1.setText(edit1.getText() + "");
                }
                else {
                    edit1.setText(edit1.getText() + "0");
                }
            }
        });

        buttonc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clear();
            }
        });
//////////////////////////////////////handling the backspace button/////////////////////////

        del.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                check();
                if (name.equals(""))
                {

                }
                else {

                    edit1.setText(name.substring(0, name.length() - 1));
                }
            }
        });








////////////////////////////////////////////Handling the result/////////////////////////////////////////////

        eql.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view){
                storePre();
                if(res1==null)
                    edit1.setText(edit1.getText()+"");
                else if(edit1!=null) {
                    edit2.setText(Double.parseDouble(edit1.getText()+"") * 2.20462 + "");
                }

            }

        });





        return view;
    }
}